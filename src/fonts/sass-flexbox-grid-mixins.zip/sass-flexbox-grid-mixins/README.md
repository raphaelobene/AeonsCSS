# Sass Flexbox Grid Mixins

A Pen created on CodePen.io. Original URL: [https://codepen.io/bebaps/pen/ZeYweN](https://codepen.io/bebaps/pen/ZeYweN).

Example how you can implement a grid via mixins only or via classes. Quick demo, highly untested.