# Pure SCSS Material Palette Generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/i_amraph/pen/ExRYbNo](https://codepen.io/i_amraph/pen/ExRYbNo).

Work to be done obvi. Feedback SO SO welcome. Thanks for looking!