import React, { Component } from "react";
import Color from "./Color";
import Button from "./Button";

class ColorPaletteGenerator extends Component {
  constructor() {
    super();
    this.state = {
      colors: [
        {
          color: "#eee",
          name: "primary",
          numberOfShades: 4
        }
      ]
    };
    this.onAddColorClick = this.onAddColorClick.bind(this);
  }
  getColorShadesString(color) {
    let shadesString = "";
    if (color.numberOfShades === "") return "";
    shadesString += `\n// Light shades \n`;
    for (let index = 1; index <= color.numberOfShades / 2; index++) {
      shadesString += `$${color.name}-light-${index}0: mix(white, $${
        color.name
      }, ${index}0%);\n`;
    }
    shadesString += `\n// Dark shades \n`;
    for (let index = 1; index <= color.numberOfShades / 2; index++) {
      shadesString += `$${color.name}-dark-${index}0: mix(black, $${
        color.name
      }, ${index}0%);\n`;
    }
    return shadesString;
  }
  onAddColorClick() {
    const { colors } = this.state;
    const colorArray = [...colors];
    let colorName = "";
    if (colors.length === 1) {
      colorName = "secondary";
    } else if (colors.length === 2) {
      colorName = "tertiary";
    }
    colorArray.push({
      color: colors[0].color,
      name: colorName,
      numberOfShades: colors[0].numberOfShades
    });
    this.setState({
      colors: colorArray
    });
  }
  onColorChange(index, color) {
    const colorArray = [...this.state.colors];
    colorArray[index].color = color;
    this.setState({
      colors: colorArray
    });
  }
  onColorNameChange(index, colorName) {
    const colorArray = [...this.state.colors];
    colorArray[index].name = colorName;
    this.setState({
      colors: colorArray
    });
  }
  onNumberOfShadesChange(index, numberOfShades) {
    const colorArray = [...this.state.colors];
    colorArray[index].numberOfShades = numberOfShades;
    this.setState({
      colors: colorArray
    });
  }
  onRemoveColorClick(index) {
    this.setState({
      colors: this.state.colors.filter((color, i) => {
        if (i === index) return false;
        return true;
      })
    });
  }
  render() {
    return (
      <div>
        {this.state.colors.map((color, i) => (
          <Color
            key={i}
            color={color}
            onChangeName={name => {
              this.onColorNameChange(i, name);
            }}
            onChangeColor={color => {
              this.onColorChange(i, color);
            }}
            onChangeNumberOfShades={number => {
              this.onNumberOfShadesChange(i, number);
            }}
            onRemove={() => {
              this.onRemoveColorClick(i);
            }}
            showRemove={this.state.colors.length > 1}
          />
        ))}
        <Button
          onClick={this.onAddColorClick}
          className="color-palette-generator__add-button"
        >
          Add color
        </Button>
        <p>Result:</p>
        <pre className="pre">
          {this.state.colors.map((color, i) => {
            if (color.name && color.color) {
              return `${i !== 0 ? "\n\n" : ""}$${color.name}: ${color.color}; 
              ${this.getColorShadesString(color)}`;
            }
          })}
        </pre>
      </div>
    );
  }
}

export default ColorPaletteGenerator;
