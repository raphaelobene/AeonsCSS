import React from "react";

const Select = ({ value, options = [], onChange, placeholder }) => {
  return (
    <div className="select">
      <select value={value} className="select__select" onChange={onChange}>
        {placeholder && <option>{placeholder}</option>}
        {options.map((option, i) => (
          <option key={i} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default Select;
