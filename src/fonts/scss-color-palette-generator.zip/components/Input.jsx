import React from "react";

const Input = ({
  inputClass = "",
  onChange,
  placeholder,
  type = "text",
  value
}) => {
  return (
    <div className="input">
      <input
        className={`input__input ${inputClass}`}
        onChange={onChange}
        placeholder={placeholder}
        type={type}
        value={value}
      />
    </div>
  );
};

export default Input;
