import React from "react";

const IconButton = ({ children, onClick, className = "" }) => {
  return (
    <button onClick={onClick} className={`icon-button ${className}`}>
      {children}
    </button>
  );
};

export default IconButton;
