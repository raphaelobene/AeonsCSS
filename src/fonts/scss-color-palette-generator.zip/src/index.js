import React from "react";
import ReactDOM from "react-dom";

import "/scss/styles.scss";
import Color from "../components/Color";
import ColorPaletteGenerator from "../components/ColorPaletteGenerator";

function App() {
  return (
    <div className="App">
      <h1>SCSS palette generator</h1>
      <ColorPaletteGenerator />
    </div>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
